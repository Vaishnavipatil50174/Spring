package com.epam.user.management.project.usermanagement.exception;

public class UserException extends RuntimeException{
    public UserException(String message) {
        super(message);
    }
}
