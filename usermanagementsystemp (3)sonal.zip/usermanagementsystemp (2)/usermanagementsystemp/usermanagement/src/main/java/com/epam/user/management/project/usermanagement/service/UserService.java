package com.epam.user.management.project.usermanagement.service;

import com.epam.user.management.project.usermanagement.exception.InvalidUserException;
import com.epam.user.management.project.usermanagement.exception.UserException;
import com.epam.user.management.project.usermanagement.model.Address;
import com.epam.user.management.project.usermanagement.model.Role;
import com.epam.user.management.project.usermanagement.model.User;
import com.epam.user.management.project.usermanagement.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    UserRepo userRepo;

    public void add(User user){
        userRepo.save(user);
    }

    public List<User> show(){
        return userRepo.findAll();
    }

    public User byId(Integer id){
        return userRepo.findById(id).orElseThrow(()-> new UserException("No Record at the"+ id));
    }
    public User update(Integer id,User user){
        User userOld=userRepo.findById(id).orElseThrow(()-> new InvalidUserException("Invalid User Exception"));
        userOld.setName(user.getName());
        List<Address>oldAddresses=userOld.getAddresses();
        List<Address>newAddresses=user.getAddresses();

        for(int i=0;i<newAddresses.size();i++){
            Address updateAddress=newAddresses.get(i);
            if(i< oldAddresses.size()){
                Address currentAddress=oldAddresses.get(i);
                currentAddress.setAddressname(updateAddress.getAddressname());

            }
            else{
                oldAddresses.add(updateAddress);
            }

        }


//        user1.setAddresses(user.getAddresses());
        userOld.setRoles(user.getRoles());
        return userRepo.save(userOld);
    }
    public void deleteRecord(Integer id){
        User user1=userRepo.findById(id).orElseThrow(()-> new UserException("No Such Record in the database"));
        userRepo.delete(user1);
    }



}
