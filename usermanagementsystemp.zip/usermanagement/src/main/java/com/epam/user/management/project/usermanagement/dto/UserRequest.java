package com.epam.user.management.project.usermanagement.dto;


import com.epam.user.management.project.usermanagement.model.Address;
import com.epam.user.management.project.usermanagement.model.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Set;

@Data
public class UserRequest {
    @NotBlank(message = "Id is Mandatory")
    String name;

    Set<Address> addresses;
    Set<Role> roles;
}
