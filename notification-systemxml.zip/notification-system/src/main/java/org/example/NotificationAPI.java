package org.example;

public interface NotificationAPI {
     void notification();
}
